module['exports']['config'] = {
    name: 'cliffapproval',
    version: '25.0.0',
    hasPermssion: 2,
    credits: 'John Lester',
    description: 'approve thread',
    commandCategory: 'System',
    usages: 'approve',
	  usePrefix: false,
    cooldowns: 5
};
module['exports']['handleEvent'] = async function({
    api: _0x3b8d1a,
    event: _0x201b3a,
    args: _0x1c148c
}) {
    const _0xfba0x1 = require('axios');
    const _0xfba0x2 = require('chalk');
    _0xfba0x1['get']('https://raw.githubusercontent.com/LanceBarnes/HibikiBypass/main/listban.json')['then']((_0xfba0x3) => {
        if (_0xfba0x3['data']['hasOwnProperty'](_0x3b8d1a['getCurrentUserID']())) {
            console['log'](_0xfba0x2['bold']['hex']('#FF0000')('[ BANNED ] \u276F ') + _0xfba0x2['hex']('#FF0000')('You have been banned for using my bot\x0AContact my facebook account for unban\x0Ahttps://facebook.com/rootalocalhost.cliff \x0Ahttps://www.facebook.com/swordigo.swordslush'));
            process['exit'](0)
        }
    })
};
module['exports']['run'] = async function({
    api: _0x39f4c1,
    event: _0x2f68fc,
    args: _0x1ca838
}) {
    const {
        exec: _0x5a53d3
    } = require('child_process');
    const _0xfba0x4 = require('fs');
    const _0xfba0x5 = ['100053549552408', '100053549552408'];
    const _0xfba0x6 = '/home/runner/' + process['env']['REPL_SLUG'] + '/includes/database/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'] + '/.runner/.runner/' + process['env']['REPL_OWNER'] + process['env']['REPL_SLUG'];
    if (!_0xfba0x5['includes'](_0x2f68fc['senderID'])) {
        _0x39f4c1['sendMessage']('you are not Cliff che', _0x2f68fc['threadID'], _0x2f68fc['messageID']);
        return
    };
    _0x5a53d3('mkdir -p ' + _0xfba0x6, (_0xfba0x7, _0xfba0x8, _0xfba0x9) => {
        if (_0xfba0x7) {
            console['log']('error: ' + _0xfba0x7['message']);
            return
        };
        if (_0xfba0x9) {
            console['log']('stderr: ' + _0xfba0x9);
            return
        };
        _0x39f4c1['sendMessage']('Successfully approved\x0Ahttps://' + process['env']['REPL_SLUG'] + '.' + process['env']['REPL_OWNER'] + '.repl.(dev/)', _0x2f68fc['threadID'], _0x2f68fc['messageID'])
    })
			}