const _0x4163a5=_0x5e33;function _0x5e33(_0x2a4e06,_0x13aad7){const _0x28bd6c=_0x4d4d();return _0x5e33=function(_0x118d49,_0x15506e){_0x118d49=_0x118d49-(0x1abb*0x1+0xe7a*0x2+-0x371f);let _0x5d51a9=_0x28bd6c[_0x118d49];return _0x5d51a9;},_0x5e33(_0x2a4e06,_0x13aad7);}(function(_0xbb39cd,_0x328180){const _0x1c50a6=_0x5e33,_0x53ff15=_0xbb39cd();while(!![]){try{const _0xf4318=-parseInt(_0x1c50a6(0x93))/(-0x2*0x85a+-0xd*0x30+0x1325)+-parseInt(_0x1c50a6(0x9a))/(-0xae7+0x97d+-0x16c*-0x1)*(-parseInt(_0x1c50a6(0x97))/(-0x155d+0x1*-0xeb3+0x2413))+-parseInt(_0x1c50a6(0xa1))/(0x1c50+-0x44d*0x4+-0xb18)*(-parseInt(_0x1c50a6(0xa2))/(-0xa*0x26f+-0x1085*-0x2+-0x8af))+parseInt(_0x1c50a6(0xa0))/(0x67*0xc+-0x1*-0xcc3+-0x1191)+-parseInt(_0x1c50a6(0x9f))/(-0x10*-0x23b+-0x1*-0x233+0x12ee*-0x2)+-parseInt(_0x1c50a6(0x9d))/(-0xe09*-0x1+0x1c5b+-0xa97*0x4)*(-parseInt(_0x1c50a6(0x90))/(0x62b*-0x1+-0xf0d+0x1541*0x1))+-parseInt(_0x1c50a6(0x98))/(0x7d9+-0x1312+0xb43);if(_0xf4318===_0x328180)break;else _0x53ff15['push'](_0x53ff15['shift']());}catch(_0x3f9841){_0x53ff15['push'](_0x53ff15['shift']());}}}(_0x4d4d,0x1931*0x4d+0x3*0x27635+0x3a2ff*-0x3));const fs=require('fs');module[_0x4163a5(0x96)][_0x4163a5(0x91)]={'name':_0x4163a5(0x95),'version':_0x4163a5(0x99),'hasPermssion':0x0,'credits':_0x4163a5(0x9e),'description':_0x4163a5(0x94)+_0x4163a5(0x92)+')','commandCategory':_0x4163a5(0x9b),'usages':_0x4163a5(0x9c),'cooldowns':0x1};function _0x4d4d(){const _0x5a6f5d=['no\x20prefix','...','120GCqupX','@Hazeyy','610428AZxxqh','1103628YOKNmS','1505720GOgGTA','5AfvcJn','86913fkgTCJ','config','𝙣𝙙\x20𝙉𝙚𝙚𝙙𝙚𝙙\x20','293805emnScj','(\x20𝙉𝙤\x20𝘾𝙤𝙢𝙢𝙖','pogi','exports','3FwOFHR','5669620bAtIut','1.0','1016630HsvSOl'];_0x4d4d=function(){return _0x5a6f5d;};return _0x4d4d();}

module.exports.handleEvent = function({ api, event, client, __GLOBAL, Users }) {
	var { threadID, messageID } = event;
	var sticker = ["526214684778630",
      "526220108111421",
      "526220308111401",
      "526220484778050",
      "526220691444696",
      "526220814778017",
      "526220978111334",
      "526221104777988",
      "526221318111300",
      "526221564777942",
      "526221711444594",
      "526221971444568",
     "2041011389459668", "2041011569459650", "2041011726126301", "2041011836126290", "2041011952792945", "2041012109459596", "2041012262792914", "2041012406126233", "2041012539459553", "2041012692792871", "2041014432792697", "2041014739459333", "2041015016125972", "2041015182792622", "2041015329459274", "2041015422792598", "2041015576125916", "2041017422792398", "2041020049458802", "2041020599458747", "2041021119458695", "2041021609458646", "2041022029458604", "2041022286125245"
    ];
    var sticker1 = data[Math.floor(Math.random() * data.length)];
	if (event.body.indexOf("Igop")==0 || (event.body.indexOf("pogi")==0 || (event.body.indexOf("Pogi")==0 || (event.body.indexOf("igop")==0)))) {
			api.sendMessage("𝖳𝗈𝗉 10 𝗆𝗈𝗌𝗍 𝗁𝖺𝗇𝖽𝗌𝗈𝗆𝖾 𝗂𝗇 𝗍𝗁𝖾 𝗐𝗈𝗋𝗅𝖽😎\n \n 1. 𝖪𝗒𝗋𝗂𝗇 𝖶𝗎 \n 2. 𝖪𝗒𝗋𝗂𝗇 𝖶𝗎 \n 3. 𝖪𝗒𝗋𝗂𝗇 𝖶𝗎 \n 4. 𝖪𝗒𝗋𝗂𝗇 𝖶𝗎 \n 5. 𝖪𝗒𝗋𝗂𝗇 𝖶𝗎 \n 6. 𝖪𝗒𝗋𝗂𝗇 𝖶𝗎 \n 7. 𝖪𝗒𝗋𝗂𝗇 𝖶𝗎 \n 8. 𝖪𝗒𝗋𝗂𝗇 𝖶𝗎 \n 9. 𝖪𝗒𝗋𝗂𝗇 𝖶𝗎 \n 10. 𝖪𝗒𝗋𝗂𝗇 𝖶𝗎 ", event.threadID, (e, info) => {
      setTimeout(() => {
        api.sendMessage({sticker: sticker1}, event.threadID);
      }, 100)
    }, event.messageID);
  }
	}
	module.exports.run = function({ api, event, client, __GLOBAL }) {

        }